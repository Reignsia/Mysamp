require('dotenv').config();
  const { Loader } = require("aoi.loader");
const { AoiClient } = require("aoi.js");
const bot = new AoiClient({
  token: process.env.TOKEN, // If You Want To Hide Your Token, Install .env File!
    prefix: ".", // Enter Bot Prefix
    intents: ["Guilds", "GuildMessages","MessageContent","GuildMembers","GuildPresences"],
    events: ["onMessage", "onInteractionCreate",  "onChannelDelete","onChannelUpdate","onChannelCreate","onMemberUpdate","onUserUpdate","onJoin","onLeave","onMessageDelete"],
    database: {
        type: "aoi.db",
        db: require("aoi.db"),
        tables: ["main"],
        path: "./database/",
        extraOptions: {
            dbType: "KeyValue"
        }
    }
});

bot.variables({
// Currency
cash: "500",
token: "0",
// Items
rod: "0",
time: "0",
// Prices
rodp: "5000",
panelp: "30000",
timep: "20000",
// Others
refer: "1",
color: "ff880a",
});
bot.status({
name: "to prefix .",
type: "LISTENING",
status: "idle",
time: 12,
});

bot.status({
name: "Bot by Reign Sia",
type: "LISTENING",
status: "idle",
time: 12,
});

bot.loadCommands("./cmds/", true);



