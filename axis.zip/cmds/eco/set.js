module.exports = [{
    name: "set",
    code: `
    $setGlobalUserVar[$message[1];$message[2];$if[$isMentioned[<$mentioned[3]>]==true;$mentioned[3];$authorID]]
    
    $onlyForIDs[706714429634379908;You can't use this]
    `
}]
