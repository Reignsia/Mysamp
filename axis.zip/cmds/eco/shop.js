module.exports = [{
    name: "shop",
    code: `
    $title[$if[$toLowercase[$message[1]]==tools;Tools Shop;Categories]]
    $description[$if[$toLowercase[$message[1]]==tools;
    :fishing_pole_and_fish: **Rod** - $customEmoji[cash;1148489876749172786]$abbreviate[$getGlobalUserVar[rodp;$authorID];1]
    ;
    **Tools** - items for earnings]]

    $color[2C2D31]
    $footer[$if[$toLowercase[$message[1]]==tools;.buy <name> (amount);.shop <category>]]
    `
}, {
    name: "buy",
    code: `
    $if[$isNumber[$message[2]]==true;
    *$username bought **x$message[2] Rods** for **$customEmoji[cash;1148489876749172786]$abbreviate[$multi[$message[2];$getGlobalUserVar[rodp;$authorID]];1]***

    $setGlobalUserVar[cash;$sub[$getGlobalUserVar[cash;$authorID];$multi[$message[2];$getGlobalUserVar[rodp;$authorID]]];$authorID]

    $setGlobalUserVar[rod;$sum[$getGlobalUserVar[rod;$authorID];$message[2]];$authorID]

    $onlyIf[$getGlobalUserVar[cash;$authorID]>=$multi[$message[2];$getGlobalUserVar[rodp;$authorID]];Not enough money];
    *$username bought a **Rod** for **$customEmoji[cash;1148489876749172786]$abbreviate[$getGlobalUserVar[rodp;$authorID];1]***

    $setGlobalUserVar[cash;$sub[$getGlobalUserVar[cash;$authorID];$getGlobalUserVar[rodp;$authorID]];$authorID]

    $setGlobalUserVar[rod;$sum[$getGlobalUserVar[rod;$authorID];100];$authorID]

    $onlyIf[$getGlobalUserVar[cash;$authorID]>=$getGlobalUserVar[rodp;$authorID];Not enough money]]
    `
}]
