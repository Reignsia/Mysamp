module.exports = [{
    name: "use",
    $if: "old",
    code: `
    $if[$toLowercase[$message[1]]==time]
    $title[Successfully added **$message[3] days** expiration date to **ID $message[2]**]
    $color[2C2D31]
    $djsEval[
const mysql = require('mysql2/promise');

// Create a pool to establish a database connection
const db = mysql.createPool({
  host: 'localhost',
  user: 'yourusername',
  password: 'yourpassword',
  database: 'ogp_panel',
});

// Function to update the server_expiration_date
async function updateServerExpirationDate(homeID, multiplier = 1) {
  try {
    // Get the current server_expiration_date value for homeID
    const [rows] = await db.query('SELECT server_expiration_date FROM ogp_server_homes WHERE home_id = ?', [homeID]);
    const selectResult = rows;
    let currentExpirationMillis = selectResult[0]?.server_expiration_date || 0;

    if (!isNaN(currentExpirationMillis)) {
      currentExpirationMillis = parseInt(currentExpirationMillis);
    } else {
      currentExpirationMillis = 0;
    }

    // Convert currentExpirationMillis to a string
    currentExpirationMillis = String(currentExpirationMillis);

    // Check if currentExpirationMillis contains 'x' and remove it
    if (currentExpirationMillis.includes('X')) {
      currentExpirationMillis = currentExpirationMillis.replace('X', '');
    }

    // Calculate the new expiration date
    const oldExpirationMillis = multiplier * 86400000;
    const newExpirationMillis = oldExpirationMillis + parseInt(currentExpirationMillis);

    // Update the database with the new expiration date
    await db.query('UPDATE ogp_server_homes SET server_expiration_date = ? WHERE home_id = ?', [newExpirationMillis, homeID]);

    console.log('Updated server_expiration_date in the database');
  } catch (err) {
    console.error('An error occurred while updating the expiration date:', err);
  }
}

// Usage example
const homeID = '$message[2]'; // Replace with your home ID
const arg3 = '$message[3]'; // Replace with the argument 3 value (optional)

if (arg3 !== undefined) {
  // If arg3 is given, multiply it by 86400000
  updateServerExpirationDate(homeID, arg3);
} else {
  // If arg3 is not given, multiply 1 by 86400000
  updateServerExpirationDate(homeID);
}]
$setGlobalUserVar[time;$sub[$getGlobalUserVar[time;$authorID];$message[3]];$authorID]

$onlyIf[$isNumber[$message[2]]==true;Home ID isn't a number]
$onlyIf[$getGlobalUserVar[time;$authorID]>=$message[3];You don't have enough time]

$elseIf[$isNumber[$message[3]]==false]
**Usage** .use <item> <home_id> <amount>
$endelseif
$else
**Usage** .use <item> <home_id> <amount>
$endif
    `
}]

