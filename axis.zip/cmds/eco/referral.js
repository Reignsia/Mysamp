module.exports = {
    name: "referral",
    code: `
    $title[$username referred by $username[$mentioned[1]]]
    $description[Both of them earned **1 $customEmoji[token;1148489876749172786]Token**]
    $color[$getVar[color]]
    
    $setGlobalUserVar[refer;1;$authorID]
    
    $setGlobalUserVar[token;$sum[$getGlobalUserVar[token;$authorID];1];$authorID]
    
    $setGlobalUserVar[token;$sum[$getGlobalUserVar[token;$mentioned[1]];1];$mentioned[1]]
    
    $onlyIf[$isMentioned[<$mentioned[1]>]==true;Mention someone]
    
    $onlyIf[$getGlobalUserVar[refer;$authorID]!=1;You can't use referrals anymore]
    `
}
