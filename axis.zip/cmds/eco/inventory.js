module.exports = [{
    name: "inventory",
    aliases: "inv",
    code: `
    $author[$username's Inventory;$userAvatar[$authorID]]
    $description[
$if[$getGlobalUserVar[rod;$authorID]!=0;**:fishing_pole_and_fish: Rod -** \`$getGlobalUserVar[rod;$authorID]\`]
$if[$getGlobalUserVar[rod;$authorID]!=0;**:hourglass: Time -** \`$getGlobalUserVar[time;$authorID]\`]
]
$color[$getVar[color]]`
}]

