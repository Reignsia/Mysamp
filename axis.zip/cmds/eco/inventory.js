module.exports = [{
    name: "inventory",
    aliases: "inv",
    code: `
    $author[$username's Inventory;$userAvatar[$authorID]]
    $description[1;
$if[$getGlobalUserVar[rod;$authorID]!=0;**�Rod -** \`$getGlobalUserVar[rod;$authorID]\`]]`}]
