module.exports = {
name: "balance",
aliases: "bal",
code: `
$if[$isMentioned[<$mentioned[1]>]==true;
$title[$username[$mentioned[1]]'s Balance]
$description[
**Cash**
$customEmoji[cash;1148489876749172786]$abbreviate[$getGlobalUserVar[cash;$mentioned[1]];1]

**Tokens**
$customEmoji[token;1148489876749172786]$abbreviate[$getGlobalUserVar[token;$mentioned[1]];1]];
$title[$username's Balance]
$description[
**Cash**
$customEmoji[cash;1148489876749172786]$abbreviate[$getGlobalUserVar[cash;$authorID];1]

**Tokens**
$customEmoji[token;1148489876749172786]$abbreviate[$getGlobalUserVar[token;$authorID];1]]] $color[2C2D31]
`}
