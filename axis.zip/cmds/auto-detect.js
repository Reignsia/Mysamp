module.exports = {
    name: "$alwaysExecute",
    code: `
    $deleteMessage[$messageID;$channelID]
    $onlyIfMessageContains[$toLowercase[$noMentionMessage];host;cheap;bobo;tnga;tanga;gago;sira;panget;pangit;]
    `
}
