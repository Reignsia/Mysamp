module.exports = [{
name: "r",
nonPrefixed: "true",
code: `
$log[Loaded $commandsCount Commands.]
$title[Reloaded Commands]
$description[$commandsCount commands]
$color[2C2D31]
$updateCommands
$deletecommand
$onlyForIDs[706714429634379908;]`
}]

