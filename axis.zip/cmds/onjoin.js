module.exports = {
    type: "onJoin",
    code: `
    $setGlobalUserVar[refer;0;$authorID]
    `
}
